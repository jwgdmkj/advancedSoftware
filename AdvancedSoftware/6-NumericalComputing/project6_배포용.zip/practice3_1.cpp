#include "my_solver.h"


void practice3_1() {
    int i, ia, j, n, l[4];
    float a[16], b[4], x[4], s[4];

    /********************************/










    /********************************/

}
