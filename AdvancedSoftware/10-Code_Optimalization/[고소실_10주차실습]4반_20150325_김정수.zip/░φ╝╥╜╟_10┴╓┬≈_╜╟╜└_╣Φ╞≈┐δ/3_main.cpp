#include <stdio.h>
#include <random>
#include <time.h>
#include <math.h>
#include <time.h>
#include <Windows.h>

#define N 50
float Taylor_series(double x, int n);
double Taylor_series_ex(double x, int n);
__int64 start, freq, end;
#define CHECK_TIME_START QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(a) QueryPerformanceCounter((LARGE_INTEGER*)&end); a = (float)((float)(end - start) / (freq / 1000.0f))
float compute_time;

void main(void)
{
	time_t start, end;
	start = time(NULL);
	printf("*** f<-8.3> = %.6e \n", Taylor_series_ex(-8.3, N)); 
	end = time(NULL); printf("%f\n", (double)(end - start));

	start = time(NULL);
	printf("*** f<-8.3> = %.6e \n", Taylor_series(-8.3, N));
	end = time(NULL); printf("%f\n", (double)(end - start));
	printf("*** f<-8.3> = %.6e \n", pow(2.71828182846, -8.3));
}


/*
		y[j] = a[deg - 1];  // Initialize result 

		// Evaluate value of polynomial using Horner's method 
		for (int i = deg - 2; i >= 0; --i) {
	//		printf("%lf %lf %lf\n", y[j], x[j], a[i]);
			y[j] = y[j] * x[j] + a[i];
		}

*/

double Taylor_series_ex(double x, int n)
{
	//a5 x + a4 : a4�� ������ 1 ��5�� 1/n!
	double e = 1 + x/n;
	
	for (int i = n-1; i >= 1; --i) {
		//coeffiecient
		e = e * x/i + 1;
	}

	return e;
}


float Taylor_series(double x, int n)
{
	float e = 1 + x / n;

	for (int i = n - 1; i >= 1; --i) {
		//coeffiecient
		e = e * x / i + 1;
	}

	return e;
}
