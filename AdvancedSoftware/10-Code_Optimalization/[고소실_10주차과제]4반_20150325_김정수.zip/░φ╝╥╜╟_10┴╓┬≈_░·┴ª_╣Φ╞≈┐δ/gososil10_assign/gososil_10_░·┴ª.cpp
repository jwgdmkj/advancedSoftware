#include <stdio.h>
#include <string.h>
#include <random>
#include <time.h>

#include <math.h>
#include <time.h>
#include <Windows.h>

__int64 start, freq, end;
#define CHECK_TIME_START QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(a) QueryPerformanceCounter((LARGE_INTEGER*)&end); a = (float)((float)(end - start) / (freq / 1000.0f))
float compute_time;
float compute_time1, compute_time2;


#define MATDIM 1024
#define HW1_N 100000
float *hw1_x, hw1_E, hw1_var1, hw1_var2;
float hw2_a, hw2_b, hw2_c, hw2_naive_ans[2], hw2_pre_ans[2];

/* hw1 */
void init_hw1(int fixed);
void hw1_calc_e();
void hw1_calc_var1();
void hw1_calc_var2();
/* hw2 */
void hw2_naive();
void hw2_safe();
float hw2_verify(float x);
/* hw3 */
void hw3_1();
void hw3_2();
float hw3_2_2(int i, float a);
void hw3_3();
void hw3_4();
short hw3_4_2(short* p1, long* p2, int i);
short hw3_4_3(short* p1, long* p2, int i);
void hw3_5();



void main(void)
{
	srand((unsigned)time(NULL));

	/* hw1 */
	puts("====== hw1 ======");
	init_hw1(1);
	CHECK_TIME_START;
	hw1_calc_var1();
	CHECK_TIME_END(compute_time);
	compute_time1 = compute_time;

	printf("hw1_calc_var1 = %f ms\n", compute_time);
	printf("hw1_calc_var1 value = %.15f\n", hw1_var1);


	CHECK_TIME_START;
	hw1_calc_e();
	hw1_calc_var2();
	CHECK_TIME_END(compute_time);
	compute_time2 = compute_time;
	printf("hw1_calc_var2 = %f ms\n", compute_time);
	printf("hw1_calc_var2 value = %.15f\n", hw1_var2);
	puts("");
	
	/* hw2 */
	puts("====== hw2 ======");
	printf("a, b, c : ");
	scanf("%f %f %f", &hw2_a, &hw2_b, &hw2_c);
	hw2_naive();
	printf("naive result    : %.15f, %.15f\n", hw2_naive_ans[0], hw2_naive_ans[1]);
	hw2_safe();
	printf("advanced result : %.15f, %.15f\n", hw2_pre_ans[0], hw2_pre_ans[1]);
	puts("");
	printf("Verifying naive ans    : %.15f, %.15f\n", hw2_verify(hw2_naive_ans[0]),
		hw2_verify(hw2_naive_ans[1]));
	printf("Verifying advanced ans : %.15f, %.15f\n", hw2_verify(hw2_pre_ans[0]),
		hw2_verify(hw2_pre_ans[1]));
	puts("");

	/* hw3 */
	hw3_1();
	hw3_2();
	hw3_3();
	hw3_4();
	hw3_5();
}

/*�л��� ���ϴ� �� ���� ���� �ۼ��Ͽ� ��ǻ�ͻ󿡼� �� ���� �󸶳� �ٸ��� �����ϴµ�
������ �ϱ� �ռ� cpp ������ 44�� �ٿ��� ���迡 �ʿ��� �����͸� �����մϴ�.
�Ű������� 1�� �ѱ�� �����ϱ⿡ ������ ������ �����͸� �����ϸ�
�Ű������� 0�� �ѱ�� ���迡 ������� ������ �����մϴ�.
���� ������ ���� �����ͷ� ������ �����մϴ�. �� ���� �ð��� �����ϰ� ����� ��
*/
void init_hw1(int fixed)
{
	float* ptr;
	hw1_x = (float*)malloc(sizeof(float) * HW1_N);
	float t = 2100000000;
	float t2 = -2100000000;

	if (fixed)
	{
		float tmp = HW1_N;
		for (int i = 0; i < HW1_N; i++)
		{
			if (i & 1) tmp -= 0.0001;
			hw1_x[i] = tmp;

			if (t > tmp)
				t = tmp;
			if (t2 < tmp)
				t2 = tmp;
		}
	}
	else
	{
		srand((unsigned)time(NULL));
		ptr = hw1_x;
		for (int i = 0; i < HW1_N; i++)
			*ptr++ = ((float)rand() / (float)RAND_MAX) * 2;
	}
	printf("%f\n", t);
	printf("%f\n", t2);
}

void hw1_calc_e()
{
//	float tmp = 0;
	for (int i = 0; i < HW1_N; i++) {
		hw1_E += hw1_x[i];
	}

	hw1_E /=  HW1_N;
	printf("%lf\n", hw1_E);
}

void hw1_calc_var1()
{
	double tmp = 0;
	double tmp2 = 0;

	for (int i = 0; i < HW1_N; i++) {
		hw1_var1 += pow(hw1_x[i], 2);
	}
	
	tmp = (double)(hw1_var1);
	tmp *= (double)HW1_N;

	hw1_var1 = 0;
	for (int i = 0; i < HW1_N; i++) {
		hw1_var1 += hw1_x[i];
	}
	tmp2 = (double)(hw1_var1);
	tmp2 *= tmp2;

	tmp -= tmp2;
	
	tmp /= (double)(HW1_N);
	tmp /= (double)(HW1_N - 1);

	
	hw1_var1 = (float)tmp;
//	hw1_var1 = sqrt(hw1_var1);
}

void hw1_calc_var2()
{
	for (int i = 0; i < HW1_N; i++) {
		hw1_var2 += pow(hw1_x[i] - hw1_E, 2);
	}

	hw1_var2 /= (HW1_N - 1);
}


/* hw2 
2�� ������( f(x) = ax^2 + bx + c = 0 )���� ���� ������ ����Ͽ� �� ���� ���� ��,
a�� c�� b���� ��������� ���� ���� ���̸� ���� ����( ( -b +- root(b^2 - 4ac) )/2a )��
�̿��� �� ���� ���� �� ����� ���� ������ ������ �ϴµ�
���⼭ ��ġ���� ����( -b + root(b^2 - 4ac) )�� �߻��մϴ�.
���� �� ������ �ذ��ϱ� ���� ���� ���Ŀ��� ����ȭ�� �Ͽ� ���� ���մϴ�.
������ �Է����δ�
1) a : 1, 		b : 10000,	c : 1
2) a : 0.0001, 	b : 9999, 	c : 0.0001
���� �ֽ��ϴ�.
*/
void hw2_naive()
{
	float value;
	value = hw2_b * hw2_b - 4 * hw2_a * hw2_c;

	hw2_naive_ans[0] = (-hw2_b + sqrt(value)) / (2 * hw2_a);
	hw2_naive_ans[1] = (-hw2_b - sqrt(value)) / (2 * hw2_a);

	/*hw2_pre_ans[0] = hw2_a * hw2_naive_ans[0] * hw2_naive_ans[0] +
		hw2_b * hw2_naive_ans[0] + hw2_c;
	hw2_pre_ans[1] = hw2_a * hw2_naive_ans[1] * hw2_naive_ans[1] +
		hw2_b * hw2_naive_ans[1] + hw2_c;*/
}

void hw2_safe()
{
	double value;
	value = (double)hw2_b * (double)hw2_b - 4 * (double)hw2_a * (double)hw2_c;
	double t =  (-hw2_b + sqrt(value));
	float q = -hw2_b + sqrt(value);

	hw2_pre_ans[0] = (2 * hw2_c) / (-sqrt(value) - hw2_b);
	hw2_pre_ans[1] = (2 * hw2_c) / ( +sqrt(value) - hw2_b);
//	hw2_pre_ans[1] = 1 / hw2_pre_ans[1];

	double vv = (2 * hw2_c) / (sqrt(value) - hw2_b);
	float v = (-sqrt(value) + hw2_b);

	/*printf("%.15f %.15f %.15f %.15f\n",vv, v, 
		-sqrt(value) + hw2_b,
		hw2_pre_ans[1]);
	printf("%f\n", hw2_a * vv * vv + hw2_b * vv + hw2_c);
	printf("%f\n", hw2_a * hw2_pre_ans[1] * hw2_pre_ans[1] + hw2_b * hw2_pre_ans[1] + hw2_c);*/
}

float hw2_verify(float x)
{
	return hw2_a * x * x + hw2_b*x + hw2_c;
}

void hw3_1() {
	float run_time;
	printf("*******************\n");
	printf("code motion\n");
	printf("*******************\n");
	srand(time(NULL));
	float a1 = 100, a2 = 10; float sum = 0;
	float a3 = pow(a1, 2);

	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		sum += pow(a1, 2) + i;
	}
	CHECK_TIME_END(run_time);
	printf("before %.3f(ms).\n", run_time * 1000);
	printf("sum %lf\n", sum);

	sum = 0;
	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		sum += a3 + i;
	}
	CHECK_TIME_END(run_time);
	printf("after %.3f(ms).\n", run_time * 1000);
	printf("sum %lf\n", sum);
}

float hw3_2_2(int i, float a) {
	return i * i > a ? i * i : a;
}
void hw3_2() {
	float run_time;
	printf("*******************\n");
	printf("Function inlining\n");
	printf("*******************\n");
	srand(time(NULL));
	float a1 = 1000; float sum = 0;
	float a3 = pow(a1, 2);

	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		sum += hw3_2_2(i, a1);
	}
	CHECK_TIME_END(run_time);
	printf("before %.3f(ms).\n", run_time * 1000);
	printf("sum %lf\n", sum);

	sum = 0;
	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		if (i * i > a1)
			sum += i * i;
		else
			sum += a1;
	}
	CHECK_TIME_END(run_time);
	printf("after %.3f(ms).\n", run_time * 1000);
	printf("sum %lf\n", sum);
}

void hw3_3() {
	float run_time;
	printf("*******************\n");
	printf("common subexpression elimination\n");
	printf("*******************\n");
	srand(time(NULL));
	float a1 = 100, a2 = 10; float sum = 0, sub = 0;
	float a3 = pow(a1, 2);

	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		sum += pow(a1, 2) + i;
		sub += pow(a1, 2) - i;
	}
	CHECK_TIME_END(run_time);
	printf("before %.3f(ms).\n", run_time * 1000);
	printf("sum %lf sub %lf\n", sum, sub);

	sum = 0; sub = 0;
	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		sum += a3 + i;
		sub += a3 - i;
	}
	CHECK_TIME_END(run_time);
	printf("after %.3f(ms).\n", run_time * 1000);
	printf("sum %lf sub %lf\n", sum, sub);
}

short hw3_4_2(short *p1, long *p2, int i) {
	*p2 = 0;
	*p1 = 1;

	if ((*p1 * i) % 2 == 0)
		return *p2;
	else
		return 1;
}
short hw3_4_3(short* p1, long* p2, int i) {
	*p2 = 0;
	*p1 = 1;

	if ((*p1 * i) % 2 == 0)
		return 0;
	else
		return 1;
}
void hw3_4() {
	float run_time;
	printf("*******************\n");
	printf("type based alias analysis\n");
	printf("*******************\n");
	srand(time(NULL));
	short a1;
	long a2;

	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		hw3_4_2(&a1, &a2, i);
	}
	CHECK_TIME_END(run_time);
	printf("before %.3f(ms).\n", run_time * 1000);

	CHECK_TIME_START;
	for (int i = 0; i < HW1_N; i++) {
		hw3_4_3(&a1, &a2, i);
	}
	CHECK_TIME_END(run_time);
	printf("after %.3f(ms).\n", run_time * 1000);
}
void hw3_5() {
	float run_time;
	printf("*******************\n");
	printf("loop fusion\n");
	printf("*******************\n");
	srand(time(NULL));
	float a[1000];
	float b[1000];
	float c[1000];

	CHECK_TIME_START;
	for (int i = 0; i < 1000; i++) {
		a[i] = i;
	}
	for (int i = 0; i < 1000; i++) {
		b[i] = i * i;
	}
	for (int i = 0; i < 1000; i++) {
		c[i] = a[i] + b[i];
	}
	CHECK_TIME_END(run_time);
	printf("before %.3f(ms).\n", run_time * 1000);
	printf("sum %lf\n", c[999]);

	CHECK_TIME_START;
	for (int i = 0; i < 1000; i++) {
		a[i] = i;
		b[i] = i * i;
		c[i] = a[i] + b[i];
	}
	CHECK_TIME_END(run_time);
	printf("after %.3f(ms).\n", run_time * 1000);
	printf("sum %lf\n", c[999]);
}