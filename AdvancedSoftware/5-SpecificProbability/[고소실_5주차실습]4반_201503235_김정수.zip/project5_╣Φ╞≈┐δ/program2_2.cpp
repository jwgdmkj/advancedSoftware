﻿#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>

#define MY_RAND_MAX 32767
#define DELTA 0.000001  //|f(xn+1)| < 델타 : 현 xn+1에 대해 함수값이 충분히 작은가
#define Nmax 50
#define EPSILON 0.00001 //|xn+1 - xn| < 엡실론 : 의미있는 진전 안 하는가

void my_func(int m, double * U) {
	int i = 0, irand;
	unsigned int iseed = (unsigned int)time(NULL);
	srand(iseed);
	printf("iseed %d\n", iseed);
	while (i < m) {
		irand = rand();
		U[i] = ((double)irand/(double)MY_RAND_MAX);
//		printf("U %lf\n", U[i]);
		i++;
	}
}

//U = Fx에 대한 값을 bisection에 대한 값을 구할 때 근사값계산
//double _f(double* x, double Ui) {
//	return CDF(x) + Remain(x) - Ui;
//}

/*
	* x가 [x3, x4] 에 있다고 한다면
Fx = x0~x3까지의 적분 값 + x3~x까지의 적분 값 으로 표현 할 수 있고
이는 [x3, x4] 범위의 사다리꼴에서 잘라낸 모양이므로
이에 대한 넓이를 구하면 됩니다. 초기구간은 [x0, xn]
	*/
//전체 범위에서 x3-x4만큼의 범위를 삭제
/*_f에서 하는게  미리 구해놓은 적분값(Fx) 예를 들면 x3까지 가지고 와서, 8페이지 식에 xm이 x3, xm+1이 x4라
* 여기에 ui뺴는 것
* 
* _f는 double x_next를 받아서 
언더바 fx는 Fx에 3)오류수정식을 더하고 -Ui을 함.
f(x) = Fx[xm] + 8페이지 식 - Ui
Fx[xm] + 8페이지 식 = 근사화한 Fx
xm <= x <= xm+1
식을 넣음.


/*
	xm <= x_next <x(m+1) 해서, 이를 만족하는 m을 찾고,
f(x_next) = Fx[m] + 8페이지 식(여기에도 m넣음) - Ui(rand로 만들어서 0~1로만든 것)을 적용
ceil빼고 (그냥 xnext가 x), 인덱스가 m 즉 xm이 xarr[m]
*/


double _f(double* Fx, double *fx, double  x_next, double* xarr, double* yarr, double * U, int N) {
	int m=0;
	for (int i = 0; i < N; i++) {
		if (xarr[i] < x_next) {
			if (xarr[i + 1] > x_next) {
				m = i;
				break;
			}
		}
	}

//	printf("m %d %d\n", m, irand);
//	printf("res %lf\n", Fx[m] + (yarr[m] + ((yarr[m + 1] - yarr[m]) / (xarr[m + 1] - xarr[m])
//		* (x_next - xarr[m]) / 2)) * (x_next - xarr[m]) - U[m]);

	return Fx[m] + (yarr[m] + ((yarr[m + 1] - yarr[m]) / (xarr[m + 1] - xarr[m])
		* (x_next - xarr[m]) / 2)) * (x_next - xarr[m]);
}

void program2_2()
{
	FILE* fp_r, *fp_w;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");

	/***************************************************/
	int N;
	double delta;
	double posx, posy, px, s;

	fscanf(fp_r, "%d %lf", &N, &delta);
	//N: 샘플림 지점의 개수 n+1 = 100
	double* Fx = new double[N];
	double* xarr = new double[N];
	double* yarr = new double[N];

	fprintf(fp_w, "%d %lf\n", N, delta);

	for (int i = 0; i < N; i++) {
		fscanf(fp_r, "%lf %lf", &posx, &posy);
		xarr[i] = posx;
		yarr[i] = posy;
//		printf("%lf\n", yarr[i]);
	}

	double tmp = 0.0;

	double sigma_sum = 0.0;
//	for (int i = 0; i <= N; i++) {
//		printf("y %lf\n", yarr[i]);
//	}
	Fx[0] = 0.0;
	for (int i = 1; i < N; i++) {
		//적분 실행, fx를 x0부터 xn까지
		//yi = f(xi), i = 0,1,2,···,n
		//사다리꼴 구하는 공식으로 
		if(i!=N-1)
			tmp = (tmp + (yarr[i] + yarr[i + 1]) * (delta / 2));
		else
			tmp = (double)(Fx[i - 1] + (yarr[i]) * (delta / 2));
		Fx[i] = tmp;
		printf("%d : %lf\n", i, Fx[i]);
	}

	//(b) 임의의 u값에 대하여 FX (x)의 역함수 값 x = F^−1(u)을 구한다.
	//구간 [0,1] 사이의 값을 갖는 Fx를, Fx-Ui을 구한다
	//Ui는 0과 1 사이 값을 가지며, fx는 fx=Fx-Ui에서 -Ui +Ui사이 값 가짐

	int i = 0;	//루프 횟수
	//초기구간 x0, xn
	double x0 = xarr[0];
	double x1 = xarr[N-1];
	double x_next;

	int nr;
	scanf("%d", &nr); //난수 개수
	fprintf(fp_w, "%d\n", nr);
	/*
	* x가 [x3, x4] 에 있다고 한다면
Fx = x0~x3까지의 적분 값 + x3~x까지의 적분 값 으로 표현 할 수 있고
이는 [x3, x4] 범위의 사다리꼴에서 잘라낸 모양이므로 
이에 대한 넓이를 구하면 됩니다. 초기구간은 [x0, xn]

언더바 fx는 Fx에 3)오류수정식을 더하고 -Ui을 함.
f(x) = Fx[xm] + 8페이지 식 - Ui
Fx[xm] + 8페이지 식 = 근사화한 Fx
xm <= x <= xm+1
	*/
	
	double* fx = new double[N];
	double* U = new double[N];
	my_func(N, U);

	unsigned int iseed = (unsigned int)time(NULL);
	int irand;
	srand(iseed);
	
	//여기에서 나온 걸 출력(nr만큼)
	for (int j = 0; j < nr; j++) {
		while (i < Nmax) {
			irand = rand() % N;
			x_next = (x0 + x1) / 2;		//xnext 중간값

			//U도 _f 패러미터에 추가할 것.
			//오직 x_next만을 쓸 것
			if (fabs(_f(Fx, fx, x_next, xarr, yarr, U, N)) < DELTA) {
				break;
			}

			//충분히 해가 입실론보다 작을 때
			//여기에서 출력된 xnext가 값
			if (fabs(x1 - x_next) < EPSILON) {
				printf("xnext %.15f\n", fabs(x_next - U[irand]));
				fprintf(fp_w,"%.15f\n", fabs(x_next - U[irand]));
				break;
			}

			if (_f(Fx, fx, x1, xarr, yarr, U, N) * _f(Fx, fx, x_next, xarr, yarr, U, N) < 0) {
				x0 = x_next;
			}
			else {
				x1 = x_next;
			}
			i++;
		}
	}

	/***************************************************/

	if (fp_r != NULL) fclose(fp_r);
	if (fp_w != NULL) fclose(fp_w);
}
