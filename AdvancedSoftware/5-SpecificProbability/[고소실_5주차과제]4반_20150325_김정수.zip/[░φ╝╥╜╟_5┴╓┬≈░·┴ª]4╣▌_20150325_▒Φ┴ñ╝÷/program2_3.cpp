﻿#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>

// HOMEWORK
void program2_3()
{
	program2_2_a();
	program2_2_b();
}

double _func(double* Fx, double* fx, double  x_next, double* xarr, double* yarr, double* U, int N) {
	int m = 0;
	for (int i = 0; i < N; i++) {
		if (xarr[i] < x_next) {
			if (xarr[i + 1] > x_next) {
				m = i;
				break;
			}
		}
	}

	return Fx[m] + (yarr[m] + ((yarr[m + 1] - yarr[m]) / (xarr[m + 1] - xarr[m])
		* (x_next - xarr[m]) / 2)) * (x_next - xarr[m]);
}

double _deria(double first, double* xarr, int mid, double x_next, double* Fx) {
	double s = (first - xarr[mid]) / (xarr[mid + 1] - xarr[mid]);

	return (1 - s) * Fx[mid] + s * Fx[mid + 1];
}

// HOMEWORK
void program2_2_a()
{
	__int64 start, freq, end;
	float resultTime = 0;

	CHECK_TIME_START;

	// something to do...
	FILE* fp_r, * fp_w, *fp_ww;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");
	fp_ww = fopen("histogram.txt", "w");

	/***************************************************/
	int N;
	double delta;
	double posx, posy, px, s;

	fscanf(fp_r, "%d %lf", &N, &delta);
	//N: 샘플림 지점의 개수 n+1 = 100
	double* Fx = new double[N];
	double* xarr = new double[N];
	double* yarr = new double[N];

	fprintf(fp_w, "%d %lf\n", N, delta);

	for (int i = 0; i < N; i++) {
		fscanf(fp_r, "%lf %lf", &posx, &posy);
		xarr[i] = posx;
		yarr[i] = posy;
		//		printf("%lf\n", yarr[i]);
	}

	double tmp = 0.0;

	double sigma_sum = 0.0;
	Fx[0] = 0.0;
	for (int i = 1; i < N; i++) {
		//적분 실행, fx를 x0부터 xn까지
		//yi = f(xi), i = 0,1,2,···,n
		//사다리꼴 구하는 공식으로 
		if (i != N - 1)
			tmp = (tmp + (yarr[i] + yarr[i + 1]) * (delta / 2));
		else
			tmp = (double)(Fx[i - 1] + (yarr[i]) * (delta / 2));
		Fx[i] = tmp;
//		printf("%d : %lf\n", i, Fx[i]);
	}

	//(b) 임의의 u값에 대하여 FX (x)의 역함수 값 x = F^−1(u)을 구한다.
	//구간 [0,1] 사이의 값을 갖는 Fx를, Fx-Ui을 구한다
	//Ui는 0과 1 사이 값을 가지며, fx는 fx=Fx-Ui에서 -Ui +Ui사이 값 가짐

	int i = 0;	//루프 횟수
	//초기구간 x0, xn
	double x0 = xarr[0];
	double x1 = xarr[N - 1];
	double x_next;

	int low = 0; int high = N - 1;
	int mid;
	int nr;
	scanf("%d", &nr); //난수 개수
	fprintf(fp_w, "%d\n", nr);

	double* fx = new double[N];
	double* U = new double[N];
	int* arr = new int[N];
	memset(arr, 0, sizeof(int) * N);
	my_func(N, U);

	unsigned int iseed = (unsigned int)time(NULL);
	int irand;
	srand(iseed);

	//여기에서 나온 걸 출력(nr만큼)
	for (int j = 0; j < nr; j++) {
		while (i < Nmax) {
			irand = rand() % N;
			x_next = (x0 + x1) / 2;		//xnext 중간값
			low = 0;
			high = N - 1;

			//U도 _func 패러미터에 추가할 것.
			//오직 x_next만을 쓸 것
			if (fabs(_func(Fx, fx, x_next, xarr, yarr, U, N)) < DELTA) {
				break;
			}

			if (fabs(x1 - x_next) < EPSILON) {
		//		printf("xnext %.15f\n", fabs(x_next - U[irand]));
				fprintf(fp_w, "%.15f\n", fabs(x_next - U[irand]));

				while (low <= high) {
					mid = (low + high) / 2;

					if (fabs(x_next - U[irand]) >= xarr[mid] && fabs(x_next - U[irand]) < xarr[mid + 1]) {
						fprintf(fp_ww, "%.15f : %lf\n", fabs(x_next - U[irand]), xarr[mid]);
			//			printf("%.15f : %lf\n\n", fabs(x_next - U[irand]), xarr[mid]);
						arr[mid] ++;
						break;
					}

					if (fabs(x_next - U[irand]) > xarr[mid + 1]) {
						low = mid + 1;
					}
					else {
						high = mid - 1;
					}
				}
				break;
			}

			if (_func(Fx, fx, x1, xarr, yarr, U, N) * _func(Fx, fx, x_next, xarr, yarr, U, N) < 0) {
				x0 = x_next;
			}
			else {
				x1 = x_next;
			}
			i++;
		}
	}

	for (int i = 0; i < N; i++) {
		printf("%d ", arr[i]);
		fprintf(fp_ww, "%d\n", arr[i]);
		if (i % 10 == 9) {
			printf("\n");
			fprintf(fp_ww, "\n");
		}
	}
	delete[] Fx, fx, U, xarr, yarr, arr;

	CHECK_TIME_END(resultTime);

	printf("The program2_2_a run time is %f(ms)..\n", resultTime * 1000.0);
}

double binarySearch(int low, int high, double *xarr, double first) {
	int mid;
	while (low <= high) {
		mid = (low + high) / 2;

		if (first >= xarr[mid] && first < xarr[mid + 1]) {
			return mid;
		}

		if (first > xarr[mid + 1]) {
			low = mid + 1;
		}
		else {
			high = mid - 1;
		}
	}
}

void program2_2_b()
{
	__int64 start, freq, end;
	float resultTime = 0;

	CHECK_TIME_START;

	// something to do...
	FILE* fp_r, * fp_w, * fp_ww;

	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table.txt", "w");

	/***************************************************/
	int N;
	double delta;
	double posx, posy, px, s;

	fscanf(fp_r, "%d %lf", &N, &delta);
	//N: 샘플림 지점의 개수 n+1 = 100
	double* Fx = new double[N];
	double* xarr = new double[N];
	double* yarr = new double[N];
	double* fx = new double[N];
	fx[0] = 0.0;

	fprintf(fp_w, "%d %lf\n", N, delta);

	for (int i = 0; i < N; i++) {
		fscanf(fp_r, "%lf %lf", &posx, &posy);
		xarr[i] = posx;
		yarr[i] = posy;
	}

	double tmp = 0.0;

	double sigma_sum = 0.0;
	Fx[0] = 0.0;
	for (int i = 1; i < N; i++) {
		//적분 실행, fx를 x0부터 xn까지
		//yi = f(xi), i = 0,1,2,···,n
		//사다리꼴 구하는 공식으로 
		if (i != N - 1) {
			fx[i] = (yarr[i] + yarr[i + 1]) * (delta / 2);
			tmp = tmp + fx[i];
//			tmp = (tmp + (yarr[i] + yarr[i + 1]) * (delta / 2));
		}
		else {
			tmp = (double)(Fx[i - 1] + (yarr[i]) * (delta / 2));
			fx[i] = tmp - Fx[i-1];
		}
		Fx[i] = tmp;
//		printf("%d : %lf, %lf\n", i, Fx[i], fx[i]);
	}

	//(b) 임의의 u값에 대하여 FX (x)의 역함수 값 x = F^−1(u)을 구한다.
	//구간 [0,1] 사이의 값을 갖는 Fx를, Fx-Ui을 구한다
	//Ui는 0과 1 사이 값을 가지며, fx는 fx=Fx-Ui에서 -Ui +Ui사이 값 가짐

	int i = 0;	//루프 횟수
	//초기구간 x0, xn
	double x0 = xarr[0];
	double x1 = xarr[N - 1];
	double x_next;

	int low = 0; int high = N - 1;
	int mid;
	int nr;
	scanf("%d", &nr); //난수 개수
	fprintf(fp_w, "%d\n", nr);

	double* U = new double[N];
	int* arr = new int[N];
	memset(arr, 0, sizeof(int) * N);
	my_func(N, U);

	unsigned int iseed = (unsigned int)time(NULL);
	int irand;
	srand(iseed);
	double first;
	//뉴턴 방식 - 초기값을 bisection으로 줄이고 시작하자.
	for (int j = 0; j < nr; j++) {
		while (i < Nmax) {
			irand = rand() % N;
			x_next = (x0 + x1) / 2;		//xnext 중간값
			low = 0;
			high = N - 1;

			//U도 _func 패러미터에 추가할 것.
			//오직 x_next만을 쓸 것
			if (fabs(_func(Fx, fx, x_next, xarr, yarr, U, N)) < DELTA) {
				break;
			}

			if (fabs(x1 - x_next) < EPSILON) {
		//		printf("xnext %.15f\n", fabs(x_next - U[irand]));
		//		fprintf(fp_w, "%.15f\n", fabs(x_next - U[irand]));
				first = fabs(x_next - U[irand]);
			}

			if (_func(Fx, fx, x1, xarr, yarr, U, N) * _func(Fx, fx, x_next, xarr, yarr, U, N) < 0) {
				x0 = x_next;
			}
			else {
				x1 = x_next;
			}
			i++;
		}

		int func_val;
		double ans;
		low = 0; high = N - 1;
		while (i < Nmax) {
			func_val = binarySearch(low, high, xarr, first);
			printf("func %lf %lf\n", xarr[func_val], first);
			ans= _deria(first, xarr, func_val, x_next, Fx);
			x_next = first - fx[func_val] / ans;
			printf("%lf %lf %lf\n", first, fx[func_val], x_next);

			if (fabs(binarySearch(0, N-1, xarr, x_next)) < DELTA)
				break;
			//충분히 해가 입실론보다 작을 때
			if (fabs(first - x_next) < EPSILON) {
				printf("ans %lf\n\n", x_next);
				break;
			}

			i++;
			first = x_next;
		}
	}


	delete[] Fx, fx, U, xarr, yarr, arr;

	CHECK_TIME_END(resultTime);

	printf("The program2_2_b run time is %f(ms)..\n", resultTime * 1000.0);
}