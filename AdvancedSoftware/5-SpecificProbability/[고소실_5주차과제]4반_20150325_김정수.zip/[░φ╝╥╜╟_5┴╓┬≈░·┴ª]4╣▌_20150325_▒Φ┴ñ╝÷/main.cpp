﻿#include "my_solver.h"

int main() {
    program2_1(); // make pdf table
    program2_2(); // create random number

    program2_3(); // HOMEWORK
    program2_4();
}
