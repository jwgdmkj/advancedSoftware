#define _USE_MATH_DEFINES
#include <math.h>
