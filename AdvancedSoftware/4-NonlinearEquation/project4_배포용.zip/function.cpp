#define _USE_MATH_DEFINES
#include <math.h>

double _f1(double x) {
	return 0.0;
}

double _fp1(double x) {
	return 0.0;
}
